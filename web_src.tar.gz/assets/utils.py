import math
import pygame


def _project(points, axis_x, axis_y):
    dots = [p[0] * axis_x + p[1] * axis_y for p in points]
    return min(dots), max(dots)


def _sat_polygon_rect_overlap(polygon_points, rect):
    """분리축 정리(SAT)로 볼록 다각형과 사각형의 교차 여부를 판정한다.
    (기존 pygame.mask 기반 픽셀 판정과 달리 Surface/마스크를 만들지 않아 훨씬 가볍다.)"""
    rect_points = [
        (rect.left, rect.top), (rect.right, rect.top),
        (rect.right, rect.bottom), (rect.left, rect.bottom),
    ]

    # 사각형은 축이 두 개(수평/수직)뿐이라 그것부터 검사
    for axis_x, axis_y in ((1.0, 0.0), (0.0, 1.0)):
        min1, max1 = _project(polygon_points, axis_x, axis_y)
        min2, max2 = _project(rect_points, axis_x, axis_y)
        if max1 < min2 or max2 < min1:
            return False

    n = len(polygon_points)
    for i in range(n):
        x1, y1 = polygon_points[i]
        x2, y2 = polygon_points[(i + 1) % n]
        edge_x, edge_y = x2 - x1, y2 - y1
        length = math.hypot(edge_x, edge_y)
        if length == 0:
            continue
        axis_x, axis_y = -edge_y / length, edge_x / length

        min1, max1 = _project(polygon_points, axis_x, axis_y)
        min2, max2 = _project(rect_points, axis_x, axis_y)
        if max1 < min2 or max2 < min1:
            return False

    return True


def check_polygon_collision(polygon_points, target_rect):
    """다각형과 사각형의 정밀 충돌 판정"""
    if len(polygon_points) < 3:
        return False

    xs = [p[0] for p in polygon_points]
    ys = [p[1] for p in polygon_points]
    bounding_rect = pygame.Rect(min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys))

    if not bounding_rect.colliderect(target_rect):
        return False

    return _sat_polygon_rect_overlap(polygon_points, target_rect)
