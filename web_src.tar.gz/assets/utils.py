import pygame

_solid_mask_cache = {}


def _get_solid_mask(size):
    """target_rect 크기의 꽉 찬 마스크를 재사용한다 (거의 항상 40x40이라 사실상 한 번만 생성됨)."""
    mask = _solid_mask_cache.get(size)
    if mask is None:
        mask = pygame.mask.Mask(size, fill=True)
        _solid_mask_cache[size] = mask
    return mask


def check_polygon_collision(polygon_points, target_rect):
    """다각형과 사각형의 정밀 마스크 충돌 판정"""
    if len(polygon_points) < 3:
        return False

    xs = [p[0] for p in polygon_points]
    ys = [p[1] for p in polygon_points]
    bounding_rect = pygame.Rect(min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys))

    if not bounding_rect.colliderect(target_rect):
        return False

    surf = pygame.Surface((bounding_rect.width, bounding_rect.height), pygame.SRCALPHA)
    local_pts = [(p[0] - bounding_rect.x, p[1] - bounding_rect.y) for p in polygon_points]
    pygame.draw.polygon(surf, (255, 255, 255, 255), local_pts)

    attack_mask = pygame.mask.from_surface(surf)
    target_mask = _get_solid_mask((target_rect.width, target_rect.height))

    offset_x = target_rect.x - bounding_rect.x
    offset_y = target_rect.y - bounding_rect.y

    return attack_mask.overlap(target_mask, (offset_x, offset_y)) is not None