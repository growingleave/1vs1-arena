import pygame
from utils import check_polygon_collision

class Wall:
    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
        self.color = (100, 100, 100)

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect)
        pygame.draw.rect(surface, (50, 50, 50), self.rect, 2)


def ghost(target, duration):
    target.status_effects['ghost'] = {'duration': duration}


def move_entity_with_walls(entity, total_dx, total_dy, walls):
    """
    엔티티를 이동시키되, 벽과의 충돌을 처리합니다.
    (1280x720 전장 비율 적용)
    """
    if getattr(entity, 'ignore_walls', False):
        entity.rect.x += total_dx
        entity.rect.y += total_dy
        entity.rect.clamp_ip(pygame.Rect(0, 0, 1280, 720))
        return

    steps = max(int(max(abs(total_dx), abs(total_dy))), 1)
    step_dx = total_dx / steps
    step_dy = total_dy / steps

    for _ in range(steps):
        entity.rect.x += step_dx
        for wall in walls:
            if entity.rect.colliderect(wall.rect):
                if step_dx > 0: 
                    entity.rect.right = wall.rect.left
                elif step_dx < 0: 
                    entity.rect.left = wall.rect.right
        
        entity.rect.y += step_dy
        for wall in walls:
            if entity.rect.colliderect(wall.rect):
                if step_dy > 0: 
                    entity.rect.bottom = wall.rect.top
                elif step_dy < 0: 
                    entity.rect.top = wall.rect.bottom
                    
    # 전장 전체 크기를 1280x720으로 제한
    entity.rect.clamp_ip(pygame.Rect(0, 0, 1280, 720))


def handle_attack_wall_collisions(attacks, walls):
    for attack in attacks:
        if getattr(attack, 'can_penetrate_walls', False):
            continue

        for wall in walls:
            if getattr(attack, 'is_dash', False):
                if hasattr(attack, 'owner') and attack.owner and attack.owner.rect.colliderect(wall.rect):
                    if hasattr(attack, 'start_time') and hasattr(attack, 'duration'):
                        attack.start_time = pygame.time.get_ticks() - attack.duration
                        break
            
            elif hasattr(attack, 'rect'):
                if attack.rect.colliderect(wall.rect):
                    if hasattr(attack, 'start_time') and hasattr(attack, 'duration'):
                        attack.start_time = pygame.time.get_ticks() - attack.duration
                        break

            elif hasattr(attack, 'get_polygon_points'):
                if check_polygon_collision(attack.get_polygon_points(), wall.rect):
                    if hasattr(attack, 'created_time') and hasattr(attack, 'lifespan'):
                        attack.created_time = pygame.time.get_ticks() - attack.lifespan
                        break
                    elif hasattr(attack, 'start_time') and hasattr(attack, 'duration'):
                        attack.start_time = pygame.time.get_ticks() - attack.duration
                        break