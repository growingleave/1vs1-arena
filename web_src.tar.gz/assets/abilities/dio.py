import sys
import pygame
import math
from utils import check_polygon_collision
from status_effects import silence, slow, forced_move, defense_mod, bind, time_slow, speed_up

# ==========================================
# [DIO - 스킬 1 전용] 직사각형 칼 투사체 (벽 충돌 지원)
# ==========================================
class DioKnifeBullet:
    def __init__(self, owner, direction):
        self.owner = owner
        self.direction = direction
        self.damage = owner.base_atk * 0.8
        self.speed = 18.0
        self.created_time = pygame.time.get_ticks()
        self.lifespan = 8000  
        self.hit_players = []
        
        self.width = 16
        self.height = 6
        self.pos_x = float(owner.rect.centerx + direction[0] * 20)
        self.pos_y = float(owner.rect.centery + direction[1] * 20)
        self.start_x = self.pos_x
        self.start_y = self.pos_y
        self.max_range = 700
        self.angle = math.degrees(math.atan2(-direction[1], direction[0]))

    def get_rect(self):
        return pygame.Rect(int(self.pos_x - self.width//2), int(self.pos_y - self.height//2), self.width, self.height)

    def update(self):
        current_speed = self.speed
        if getattr(self.owner, 'dio_knife_stopped', False):
            current_speed = 0.0

        time_scale = getattr(self.owner, 'time_scale', 1.0)
        self.pos_x += self.direction[0] * current_speed * time_scale
        self.pos_y += self.direction[1] * current_speed * time_scale

        main_module = sys.modules.get('__main__')
        if main_module:
            walls = getattr(main_module, 'walls', [])
            knife_rect = self.get_rect()
            for wall in walls:
                if wall.rect.colliderect(knife_rect):
                    self.lifespan = 0  
                    break

    def is_expired(self):
        time_over = pygame.time.get_ticks() - self.created_time >= self.lifespan
        out_of_range = math.hypot(self.pos_x - self.start_x, self.pos_y - self.start_y) >= self.max_range
        return time_over or out_of_range

    def collides_with(self, target):
        if target == self.owner or getattr(target, 'invincible', False) or target.defense >= 100.0:
            return False
        return self.get_rect().colliderect(target.rect)

    def apply_effect(self, target):
        pass

    def draw(self, surface):
        surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        pygame.draw.rect(surf, (220, 220, 240), (0, 0, self.width, self.height))
        pygame.draw.rect(surf, (50, 50, 50), (0, 0, self.width, self.height), 1)
        
        rotated_surf = pygame.transform.rotate(surf, self.angle)
        rect = rotated_surf.get_rect(center=(int(self.pos_x), int(self.pos_y)))
        surface.blit(rotated_surf, rect.topleft)


# ==========================================
# [평타 - J키] 정사각형(스탠드) 양옆에서 C자 모양 호를 그리며 전방을 타격하는 콤보 (인덱스 0)
# ==========================================
class DioPunchHitbox:
    def __init__(self, owner, x, y, width, height, damage):
        self.owner = owner
        self.pos_x = x
        self.pos_y = y
        self.width = width
        self.height = height
        self.damage = damage
        self.created_time = pygame.time.get_ticks()
        self.lifespan = 150
        self.hit_players = []

    def get_rect(self):
        return pygame.Rect(int(self.pos_x - self.width//2), int(self.pos_y - self.height//2), self.width, self.height)

    def update(self):
        pass

    def is_expired(self):
        return pygame.time.get_ticks() - self.created_time >= self.lifespan

    def collides_with(self, target):
        if target == self.owner or getattr(target, 'invincible', False) or target.defense >= 100.0:
            return False
        return self.get_rect().colliderect(target.rect)

    def apply_effect(self, target):
        pass

    def draw(self, surface):
        rect = self.get_rect()
        surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        pygame.draw.rect(surf, (255, 255, 255, 220), (0, 0, self.width, self.height), border_radius=6)
        surface.blit(surf, rect.topleft)


class DioBasicPunchManager:
    def __init__(self, owner, direction, attacks_list):
        self.owner = owner
        self.direction = direction
        self.attacks_list = attacks_list
        self.damage = owner.base_atk * 0.65  # 2회 타격 총합 1.3배
        self.created_time = pygame.time.get_ticks()
        self.lifespan = 450  # 전체 콤보 유지 시간
        self.hit_players = []
        
        # 사각형(스탠드) 크기 설정 (캐릭터와 동일)
        self.box_size = owner.rect.width
        
        # 방향 벡터 및 직교(좌우) 벡터 계산
        dir_vec = pygame.math.Vector2(direction[0], direction[1])
        if dir_vec.length_squared() == 0:
            dir_vec = pygame.math.Vector2(1, 0)
        else:
            dir_vec = dir_vec.normalize()
            
        self.perp_vec = pygame.math.Vector2(-dir_vec.y, dir_vec.x)
        
        # 사각형 박스의 중심 좌표 (캐릭터 전방에 위치)
        dist = 35 + self.box_size // 2
        self.box_x = float(owner.rect.centerx + dir_vec.x * dist)
        self.box_y = float(owner.rect.centery + dir_vec.y * dist)
        
        # 그림의 구조대로 사각형의 양옆(위/아래 또는 좌/우)에서 전방을 향해 뻗어나가는 펀치 위치 계산
        offset = self.box_size * 0.55
        
        # 첫 번째 펀치: 위쪽(또는 한쪽)에서 C자 호를 그리며 타격 (0ms)
        self.fist1_x = self.box_x + self.perp_vec.x * offset + dir_vec.x * (self.box_size * 0.2)
        self.fist1_y = self.box_y + self.perp_vec.y * offset + dir_vec.y * (self.box_size * 0.2)
        
        fist_w = int(self.box_size * 0.5)
        fist_h = int(self.box_size * 0.5)
        
        self.attacks_list.append(DioPunchHitbox(self.owner, self.fist1_x, self.fist1_y, fist_w, fist_h, self.damage))
        
        # 두 번째 펀치 좌표 미리 계산 (반대쪽에서 C자 호를 그리며 타격)
        self.fist2_x = self.box_x - self.perp_vec.x * offset + dir_vec.x * (self.box_size * 0.2)
        self.fist2_y = self.box_y - self.perp_vec.y * offset + dir_vec.y * (self.box_size * 0.2)
        self.fist_w = fist_w
        self.fist_h = fist_h
        
        self.punch2_triggered = False

    def get_box_rect(self):
        return pygame.Rect(int(self.box_x - self.box_size//2), int(self.box_y - self.box_size//2), self.box_size, self.box_size)

    def update(self):
        now = pygame.time.get_ticks()
        elapsed = now - self.created_time
        
        # 두 번째 펀치: 반대쪽에서 C자 호를 그리며 타격 (200ms 지점)
        if not self.punch2_triggered and elapsed >= 200:
            self.punch2_triggered = True
            self.attacks_list.append(DioPunchHitbox(self.owner, self.fist2_x, self.fist2_y, self.fist_w, self.fist_h, self.damage))

    def is_expired(self):
        return pygame.time.get_ticks() - self.created_time >= self.lifespan

    def collides_with(self, target):
        return False

    def apply_effect(self, target):
        pass

    def draw(self, surface):
        now = pygame.time.get_ticks()
        elapsed = now - self.created_time
        
        # 1. 전방에 생성되는 정사각형 박스(스탠드) 렌더링
        box_rect = self.get_box_rect()
        surf = pygame.Surface((self.box_size, self.box_size), pygame.SRCALPHA)
        pygame.draw.rect(surf, (255, 215, 0, 60), (0, 0, self.box_size, self.box_size))
        pygame.draw.rect(surf, (255, 255, 255, 200), (0, 0, self.box_size, self.box_size), 2)
        surface.blit(surf, box_rect.topleft)
        
        # 2. 그림처럼 사각형 측면에서 전방을 향해 감싸며 휘둘러지는 명확한 C자 모양 호 이펙트
        c_surf = pygame.Surface((int(self.box_size * 2.0), int(self.box_size * 2.0)), pygame.SRCALPHA)
        
        # 첫 번째 C자 스윙 (0 ~ 200ms)
        if elapsed < 220:
            pygame.draw.arc(c_surf, (255, 255, 255, 230), (0, 0, int(self.box_size * 1.2), int(self.box_size * 1.2)), 0.0, 3.14, 5)
            surface.blit(c_surf, (int(self.fist1_x - self.box_size * 0.6), int(self.fist1_y - self.box_size * 0.6)))
            
        # 두 번째 C자 스윙 (200ms 이후)
        if elapsed >= 200:
            c_surf.fill((0, 0, 0, 0))
            pygame.draw.arc(c_surf, (255, 255, 255, 230), (0, 0, int(self.box_size * 1.2), int(self.box_size * 1.2)), 3.14, 6.28, 5)
            surface.blit(c_surf, (int(self.fist2_x - self.box_size * 0.6), int(self.fist2_y - self.box_size * 0.6)))


class DioBasicAttack:
    def __init__(self):
        self.name = "Stand C-Curve Punch Combo"
        self.cooldown = 480  # 콤보 종료 후 재사용 대기시간
        self.last_used = 0

    def can_use(self):
        return pygame.time.get_ticks() - self.last_used >= self.cooldown

    def use(self, owner, direction, attacks_list, color):
        self.last_used = pygame.time.get_ticks()
        attacks_list.append(DioBasicPunchManager(owner, direction, attacks_list))


# ==========================================
# [스킬 1 - K키] 최대 5개 충전형 칼 던지기 (인덱스 1)
# ==========================================
class DioSkill1:
    def __init__(self):
        self.name = "Knife Throw (Charge)"
        self.cooldown = 250        
        self.last_used = 0
        self.max_charges = 5       
        self.current_charges = 5   
        self.charge_cooldown = 1500  
        self.last_charge_time = pygame.time.get_ticks()
        
        self.cooldown_type = 'charges'

    def update_charges(self):
        now = pygame.time.get_ticks()
        if self.current_charges < self.max_charges:
            if now - self.last_charge_time >= self.charge_cooldown:
                self.current_charges += 1
                self.last_charge_time = now

    def can_use(self):
        self.update_charges()
        return self.current_charges > 0 and (pygame.time.get_ticks() - self.last_used >= self.cooldown)

    def use(self, owner, direction, attacks_list, color):
        self.update_charges()
        if self.current_charges > 0:
            self.last_used = pygame.time.get_ticks()
            self.current_charges -= 1
            if self.current_charges == self.max_charges - 1:
                self.last_charge_time = pygame.time.get_ticks()
            attacks_list.append(DioKnifeBullet(owner, direction))


# ==========================================
# [스킬 2 - L키] THE WORLD (인덱스 2)
# ==========================================
class DioTimeStopEffect:
    def __init__(self, owner, target, duration_sec):
        self.owner = owner
        self.target = target
        self.duration = duration_sec
        self.created_time = pygame.time.get_ticks()
        self.hit_players = []

    def update(self, walls=None):
        pass

    def is_expired(self):
        elapsed_sec = (pygame.time.get_ticks() - self.created_time) / 1000.0
        expired = elapsed_sec >= self.duration
        if expired:
            if self.target:
                self.target.stunned = False
            if self.owner:
                self.owner.dio_knife_stopped = False  
        return expired

    def collides_with(self, target):
        return False

    def apply_effect(self, target):
        pass

    def draw(self, surface):
        surf = pygame.Surface((surface.get_width(), surface.get_height()), pygame.SRCALPHA)
        surf.fill((10, 10, 30, 120))
        surface.blit(surf, (0, 0))


class DioSkill2:
    def __init__(self):
        self.name = "The World (Time Stop)"
        self.cooldown = 12000
        self.last_used = 0
        self.owner = None
        self.skill1_ref = None  

    def can_use(self):
        return pygame.time.get_ticks() - self.last_used >= self.cooldown

    def use(self, owner, direction, attacks_list, color):
        self.owner = owner
        self.last_used = pygame.time.get_ticks()
        
        if self.skill1_ref:
            self.skill1_ref.current_charges = 5
            self.skill1_ref.last_charge_time = pygame.time.get_ticks()
        
        target = getattr(owner, 'opponent', None)
        if target:
            duration_sec = 3.0
            power_val = 100.0

            time_slow(target, duration_sec, power_val)
            slow(target, duration_sec, power_val)
            silence(target, duration_sec)
            target.stunned = True

            owner.dio_knife_stopped = True

            attacks_list.append(DioTimeStopEffect(owner, target, duration_sec))


# ==========================================
# DIO 캐릭터 데이터 등록 매핑
# ==========================================
def apply_dio(player):
    player.base_atk = 15
    player.max_hp = 100
    player.hp = 100
    player.speed = 4.7
    player.is_dio = True
    player.dio_knife_stopped = False
    
    skill1 = DioSkill1()
    skill2 = DioSkill2()
    skill2.skill1_ref = skill1  
    
    player.abilities = [
        DioBasicAttack(),   # 인덱스 0: 평타 - 전방 정사각형(스탠드) 양옆에서 C자 호를 그리며 휘두르는 스윙 콤보 (J키)
        skill1,             # 인덱스 1: 스킬 1 - 5개 충전형 칼 던지기 (K키)
        skill2,             # 인덱스 2: 스킬 2 - 시간 정지 + 칼 즉시 5개 충전 (L키)
        None                # 인덱스 3: 궁극기 (O키)
    ]
    
    def custom_reset():
        player.is_dio = False
        player.dio_knife_stopped = False
        player.custom_reset = None

    player.custom_reset = custom_reset

DIO_CHARACTER_DATA = {
    "name": "DIO",
    "desc": "전방의 정사각형(스탠드) 양옆에서 C자 모양 호를 그리며 주먹을 휘두르는 평타와 충전형 칼 던지기(스킬 1), 5초간 시간 정지(스킬 2) 능력을 지닌 흡혈귀",
    "apply": apply_dio
}